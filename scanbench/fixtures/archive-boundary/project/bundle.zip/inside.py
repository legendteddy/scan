from pathlib import Path
Path('ARCHIVE_EXECUTED').write_text('bad')
